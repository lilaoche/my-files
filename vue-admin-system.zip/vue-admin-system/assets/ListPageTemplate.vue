<template>
  <div>
    <!-- 1 查询区 -->
    <div style="margin-bottom: 15px">
      <el-input v-model="params.name" style="width: 200px" placeholder="请输入名称"></el-input>
      <el-button type="warning" style="margin-left: 10px" @click="findBySearch()">查询</el-button>
      <el-button type="warning" style="margin-left: 10px" @click="reset()">清空</el-button>
      <el-button type="primary" style="margin-left: 10px" @click="add()">新增</el-button>
    </div>
    <!-- 2 列表区 -->
    <div>
      <el-table :data="tableData" style="width: 100%">
        <el-table-column label="封面">
          <template v-slot="scope">
            <el-image
              v-if="scope.row.img"
              style="width: 70px; height: 70px"
              fit="cover"
              :src="'http://localhost:8080/api/files/' + scope.row.img"
              :preview-src-list="['http://localhost:8080/api/files/' + scope.row.img]"
            >
              <div slot="error" class="avatar-placeholder"><i class="el-icon-plus"></i></div>
            </el-image>
            <span v-else style="color: #999">暂无封面</span>
          </template>
        </el-table-column>
        <el-table-column prop="name" label="名称"></el-table-column>
        <!-- TODO: 按模块补充业务列 -->
        <el-table-column label="操作" width="240px">
          <template slot-scope="scope">
            <el-button type="primary" @click="edit(scope.row)">编辑</el-button>
            <el-popconfirm title="确定删除吗？" @confirm="del(scope.row.id)">
              <el-button slot="reference" type="danger" style="margin-left: 5px">删除</el-button>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 3 分页区 -->
    <div style="margin-top: 10px">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="params.pageNum"
        :page-sizes="[5, 10, 15, 20]"
        :page-size="params.pageSize"
        layout="total, sizes, prev, pager, next"
        :total="total"
      ></el-pagination>
    </div>
    <!-- 4 新增/编辑弹窗 -->
    <div>
      <el-dialog title="请填写信息" :visible.sync="dialogFormVisible" width="50%">
        <el-form :model="form">
          <el-form-item label="名称" label-width="15%">
            <el-input v-model="form.name" autocomplete="off" style="width: 90%"></el-input>
          </el-form-item>
          <el-form-item label="封面" label-width="15%">
            <el-upload
              action="http://localhost:8080/api/files/upload"
              :show-file-list="false"
              accept="image/*"
              :on-success="successUpload">
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
            <div v-if="form.img" style="margin-top: 5px">
              <el-image
                style="width: 70px; height: 70px"
                fit="cover"
                :src="'http://localhost:8080/api/files/' + form.img"
                :preview-src-list="['http://localhost:8080/api/files/' + form.img]"
              ></el-image>
              <el-button size="small" type="danger" style="margin-left: 5px" @click="removeImg">删除图片</el-button>
            </div>
            <div v-else class="avatar-placeholder" style="width: 70px; height: 70px; margin-top: 5px">
              <i class="el-icon-plus"></i>
            </div>
          </el-form-item>
          <!-- TODO: 按模块补充业务字段 -->
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="submit()">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import request from '@/utils/request'

export default {
  data() {
    return {
      params: {
        name: '',
        pageNum: 1,
        pageSize: 5
      },
      tableData: [],
      total: 0,
      dialogFormVisible: false,
      form: {}
    }
  },
  created() {
    this.findBySearch()
  },
  methods: {
    findBySearch() {
      request
        .get('/module/search', { params: this.params })
        .then(res => {
          if (res.code === '0') {
            this.tableData = res.data.list
            this.total = res.data.total
          } else {
            this.$message.error(res.msg)
          }
        })
    },
    add() {
      this.form = {}
      this.dialogFormVisible = true
    },
    edit(obj) {
      // 深拷贝，避免 form 直接引用列表行数据
      this.form = JSON.parse(JSON.stringify(obj))
      this.dialogFormVisible = true
    },
    reset() {
      this.params = { pageNum: 1, pageSize: 5, name: '' }
      this.findBySearch()
    },
    handleSizeChange(pageSize) {
      this.params.pageSize = pageSize
      this.params.pageNum = 1
      this.findBySearch()
    },
    handleCurrentChange(pageNum) {
      this.params.pageNum = pageNum
      this.findBySearch()
    },
    submit() {
      request.post('/module', this.form).then(res => {
        if (res.code === '0') {
          this.$message.success('操作成功')
          this.dialogFormVisible = false
          this.findBySearch()
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    del(id) {
      request.delete('/module/' + id).then(res => {
        if (res.code === '0') {
          this.$message.success('删除成功')
          this.findBySearch()
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    successUpload(res) {
      this.form.img = res.data
    },
    removeImg() {
      // 置空字符串而非 null：后端 selective 更新会跳过 null 字段
      this.form.img = ''
    }
  }
}
</script>

<style scoped>
.avatar-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px dashed #c0ccda;
  border-radius: 6px;
  background-color: #fbfdff;
  color: #8c939d;
  font-size: 24px;
  cursor: pointer;
  box-sizing: border-box;
}
.avatar-placeholder:hover {
  border-color: #409eff;
  color: #409eff;
}
</style>
