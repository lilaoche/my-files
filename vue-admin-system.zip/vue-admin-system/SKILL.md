---
name: vue-admin-system
description: 本技能用于开发基于 Vue2 + Element UI 的后台管理系统（常配合 SpringBoot 后端）。当用户要求：搭建/编写管理系统的列表页（CRUD）、新增编辑弹窗、分页查询、图片上传与展示、富文本编辑器、权限控制，或排查此类系统的 Bug（图片不显示、编辑未保存生效、上传失败、分页异常等）时，应使用本技能。涵盖标准页面结构、代码模板和常见陷阱。
---

# Vue Admin System

## Overview

为 Vue2 + Element UI 后台管理系统提供标准开发范式：CRUD 页面结构、弹窗表单、图片上传展示、富文本、分页，以及前后端联调中的高频陷阱与修复方案。

## 技术栈约定

- 前端：Vue 2.x + Element UI + axios（封装为 `@/utils/request`，baseURL 为 `http://localhost:8080/api`）
- 后端：SpringBoot + tk.mybatis（通用 Mapper）+ PageHelper 分页
- 统一响应结构：`{ code: '0', msg: '', data: ... }`，`code === '0'` 表示成功

## 开发新 CRUD 页面

按 `assets/ListPageTemplate.vue` 模板创建页面，包含五个区块（顺序固定）：

1. **查询区**：`el-input`/`el-select` 绑定 `params`，查询与清空按钮
2. **列表区**：`el-table :data="tableData"`，操作列含 编辑/删除（删除必须用 `el-popconfirm` 二次确认）
3. **分页区**：`el-pagination` 绑定 `pageNum`/`pageSize`，`total`
4. **新增/编辑弹窗**：`el-dialog` + `el-form`，新增与编辑共用一个 `form` 对象
5. **详情弹窗**（可选）：`el-dialog` 内静态表格展示行数据

接口约定：

- 查询：`GET /<模块>/search`（params 携带查询条件 + 分页参数）
- 新增/编辑：`POST /<模块>`（`id` 为空走新增，非空走更新）
- 删除：`DELETE /<模块>/{id}`

## 图片上传与展示规范

后端 `FileController` 的 `POST /files/upload` 只返回时间戳 flag，**必须拼接完整 URL**：

```js
handleAvatarSuccess(response) {
  this.form.avatar = `http://localhost:8080/api/files/${response.data}`
}
```

展示规范（所有图片位统一遵循）：

- `el-upload` 加 `:show-file-list="false"`，用 `accept="image/*"`
- 有图：`el-image` 展示，`fit="cover"`，配 `preview-src-list` 支持点击放大
- 无图或加载失败：用 `error` 插槽 + `v-else` 显示虚线边框加号占位框（样式类 `avatar-placeholder`）
- 编辑时若需删除图片，将字段置为**空字符串 `''` 而非 `null`**（原因见陷阱 1）

## 富文本编辑器（wangeditor）

- 编辑器实例存模块级变量，`setTimeout(0)` 后初始化，避免 DOM 未挂载
- 上传接口配置 `uploadImgServer = 'http://localhost:8080/api/files/wang/upload'`，`uploadFileName = 'file'`
- 打开弹窗时用 `editor.txt.html(content)` 回显；提交前用 `editor.txt.html()` 取值赋给 `form.content`

## 常见陷阱（排查 Bug 时必读）

详见 `references/pitfalls.md`，核心三条：

1. **后端 selective 更新跳过 null**：`updateByPrimaryKeySelective` 不更新值为 `null` 的字段。前端清空字段须传 `''`。
2. **编辑弹窗直接引用行对象**：`this.form = obj` 会同步修改列表行数据。须 `JSON.parse(JSON.stringify(obj))` 深拷贝。
3. **上传返回值是 flag 不是 URL**：直接当 `src` 用必然 404，落入 error 插槽，表现为"传了图但显示占位框/加载失败"。

## Resources

### assets/
- `ListPageTemplate.vue`：标准 CRUD 页面完整模板，新建页面时复制到 `src/views/` 后按模块改名改字段

### references/
- `pitfalls.md`：常见陷阱完整清单（含现象、根因、修复代码），排查 Bug 时加载
