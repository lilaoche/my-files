# Vue Admin 常见陷阱清单

排查此类系统 Bug 时，先按下表"现象 → 根因"对照。

## 1. 后端 selective 更新跳过 null 字段

**现象**：编辑弹窗里清空了某字段（如封面、头像）并保存，列表/数据库里旧值依然存在。

**根因**：tk.mybatis 的 `updateByPrimaryKeySelective` 只更新非 `null` 字段。前端把字段设为 `null` 或不传，后端直接跳过。

**修复**：前端清空时置为空字符串：

```js
removeImg() {
  this.form.img = ''  // 而不是 null
}
```

若字段是数字/日期等无法用 `''` 的类型，须在后端 Service 里显式处理（如 `book.setImg("")` 或改用非 selective 更新）。

## 2. 编辑弹窗直接引用表格行对象

**现象**：编辑弹窗里上传了新图（或改了字段）但点了"取消"，列表里的数据也被改了。

**根因**：`this.form = obj` 使 form 与行数据指向同一引用，任何修改直接反映到列表。

**修复**：

```js
edit(obj) {
  this.form = JSON.parse(JSON.stringify(obj))
  this.dialogFormVisible = true
}
```

## 3. 上传接口只返回 flag，不是图片地址

**现象**：Network 显示 upload 返回 `code: "0"`，但页面显示占位框 / "加载失败"。

**根因**：后端 `POST /files/upload` 只返回时间戳 flag（如 `1791460398460`），文件实际以 `flag-文件名` 存盘，需通过 `GET /files/{flag}` 访问。前端把 flag 直接当 `src` 使用，请求相对路径必然 404，触发 `el-image` 的 error 插槽。

**修复**：上传成功回调里拼接完整 URL：

```js
handleAvatarSuccess(response) {
  this.form.avatar = `http://localhost:8080/api/files/${response.data}`
}
```

注意 wang-editor 的 `/files/wang/upload` 接口已返回完整 URL，无需再拼。

## 4. 图片位没有空值兜底

**现象**：记录无图时渲染 `http://localhost:8080/api/files/`（空 flag）或 `undefined`，出现裂图/"加载失败"。

**修复**：渲染前判空 + error 插槽兜底：

```html
<el-image v-if="row.img" :src="baseUrl + row.img">
  <div slot="error" class="avatar-placeholder"><i class="el-icon-plus"></i></div>
</el-image>
<span v-else>暂无封面</span>
```

占位样式（虚线框 + 加号，悬浮变主题色）：

```css
.avatar-placeholder {
  display: flex; align-items: center; justify-content: center;
  border: 1px dashed #c0ccda; border-radius: 6px;
  background-color: #fbfdff; color: #8c939d;
  font-size: 24px; cursor: pointer; box-sizing: border-box;
}
.avatar-placeholder:hover { border-color: #409eff; color: #409eff; }
```

## 5. el-upload 文件列表的 × 不等于删除图片

**现象**：用户点了上传组件文件列表的 ×，以为删掉了图，保存后旧图仍在。

**根因**：× 只移除 el-upload 内部的显示项，`form.img` 未变。

**修复**：`:show-file-list="false"` 关掉文件列表，提供显式的"删除图片"按钮把字段置 `''`。

## 6. Vue 2 响应式限制

**现象**：给对象新增属性后视图不更新。

**根因**：Vue 2 无法侦测直接赋值的新增属性。

**修复**：`this.$set(obj, 'avatar', val)`，或赋值后 `this.$forceUpdate()`；初始化 `form` 时把会用到的字段全部声明出来。

## 7. wangeditor 实例重复创建 / 回显失败

**现象**：弹窗多次打开后编辑器失灵，或回显空白。

**修复**：编辑器实例存模块级变量（组件外 `let editor`），只在 `!editor` 时 `new E(...)` 并 `create()`；每次打开弹窗用 `editor.txt.html(content)` 回显；初始化包在 `setTimeout(..., 0)` 中等待 DOM 挂载。

## 8. 分页 total 与查询条件不一致

**现象**：翻页后数据重复或丢失。

**修复**：每次 `findBySearch()` 前，若查询条件变化须把 `params.pageNum` 重置为 1；`el-pagination` 的 `size-change` 里也要重置 `pageNum`。
